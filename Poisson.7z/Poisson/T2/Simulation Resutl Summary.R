##########################################################################
############################# Simulation Resutl Summary ##################
##########################################################################
setwd("C:/Users/z021w783/Desktop/GRA/Disertation/Results")
#creat tables
temp_result <- matrix(rep(0,13), nrow =1, byrow=TRUE)
colnames(temp_result) = c('false_p','false_n','sensitivity','specificity','MSE','SSE','MAE','MSE','MSR','MST','adjusted R2','Pearson_statistic','deviance_statistic')
summary_result_1<- NULL
summary_result_2<- NULL
summary_result_3<- NULL
summary_result_4<- NULL
summary_result_5<- NULL
summary_result_6<- NULL
T <- 0

#loading GLM IP methods of gglasso and sparsegl
repeat{

  for (j in 1:5) {
source("C:/Users/z021w783/Desktop/GRA/Disertation/Code/GLM Paper final library/GLM Iterative Proximal (IP) Algorithm Sparse Regression for Poisson V_gglasso4.R")
source("C:/Users/z021w783/Desktop/GRA/Disertation/Code/GLM Paper final library/GLM Iterative Proximal (IP) Algorithm Sparse Regression for Poisson V_sparsegl4.R")
#Implement simulation
#source("C:/Users/z021w783/Desktop/GRA/Disertation/Code/GLM Paper final library/Simulation.R")
source("C:/Users/z021w783/Desktop/GRA/Disertation/Code/GLM Paper final library/SimulationV2.R")
#source("C:/Users/z021w783/Desktop/GRA/Disertation/Code/GLM Paper final library/SimulationV3.R")
#temp[,c(1,2,3,7)]
  
#gglasso_result <- 1
############################################################
  T1 <- as.vector(temp[,1])
  T2 <- as.vector(temp[,7])
  temp_result[1,1] <- length(which(T1[which(T2==0)] != 0)) #false positive for variable selection
  temp_result[1,2] <- length(which(T1[which(T2!=0)] == 0)) #false negative for variable selection
  temp_result[1,3] <- length(which(T1[which(T2!=0)] != 0))/length(which(T2 != 0)) #sensitivity for variable selection
  temp_result[1,4] <- length(which(T1[which(T2==0)] == 0))/length(which(T2 == 0)) #specificity for variable selection
  temp_result[1,5] <- mean((T1-T2)^2)  #MSE
  temp_result[1,6] <- sum((T1-T2)^2)  #SSE
  temp_result[1,7] <- mean(abs(T1-T2))  #MAE
  p_prediction <- round(X%*%T1,4)
  p_prediction[which(p_prediction<=0)] <- 0
  y_prediction <- rpois(dim(X)[1],p_prediction)
  temp_result[1,8] <- mean((y_prediction-mean(y))^2) #MSR  mean residual sum of squares
  temp_result[1,9] <- mean((y-y_prediction)^2) #MSE  mean estimation sum of squares
  temp_result[1,10] <- mean((y-mean(y))^2) #MST mean total sum of squares
  temp_result[1,11] <- 1-(sum((y_prediction-mean(y))^2)/(dim(X)[1]-length(which(T1!=0))))/(sum((y-mean(y))^2)/(dim(X)[1]-1)) #adjusted R2
  y_prediction[which(y_prediction==0)] <- 0.01
  temp_result[1,12] <- sum((y-y_prediction)^2/y_prediction)/dim(X)[1]
  temp1 <- y/y_prediction
  temp1[which(temp1==0)]<-0.0001
  temp_result[1,13] <- (2*sum(y*log(temp1)-(y-y_prediction)))/dim(X)[1]
  summary_result_1 <- rbind(temp_result,summary_result_1)
  
#sparsegl_result <- 2
  ############################################################
  T1 <- as.vector(temp[,2])
  T2 <- as.vector(temp[,7])
  temp_result[1,1] <- length(which(T1[which(T2==0)] != 0)) #false positive for variable selection
  temp_result[1,2] <- length(which(T1[which(T2!=0)] == 0)) #false negative for variable selection
  temp_result[1,3] <- length(which(T1[which(T2!=0)] != 0))/length(which(T2 != 0)) #sensitivity for variable selection
  temp_result[1,4] <- length(which(T1[which(T2==0)] == 0))/length(which(T2 == 0)) #specificity for variable selection
  temp_result[1,5] <- mean((T1-T2)^2)  #MSE
  temp_result[1,6] <- sum((T1-T2)^2)  #SSE
  temp_result[1,7] <- mean(abs(T1-T2))  #MAE
  p_prediction <- round(X%*%T1,4)
  p_prediction[which(p_prediction<=0)] <- 0
  y_prediction <- rpois(dim(X)[1],p_prediction)
  temp_result[1,8] <- mean((y_prediction-mean(y))^2) #MSR  mean residual sum of squares
  temp_result[1,9] <- mean((y-y_prediction)^2) #MSE  mean estimation sum of squares
  temp_result[1,10] <- mean((y-mean(y))^2) #MST mean total sum of squares
  temp_result[1,11] <- 1-(sum((y_prediction-mean(y))^2)/(dim(X)[1]-length(which(T1!=0))))/(sum((y-mean(y))^2)/(dim(X)[1]-1)) #adjusted R2
  y_prediction[which(y_prediction==0)] <- 0.01
  temp_result[1,12] <- sum((y-y_prediction)^2/y_prediction)/dim(X)[1]
  temp1 <- y/y_prediction
  temp1[which(temp1==0)]<-0.0001
  temp_result[1,13] <- (2*sum(y*log(temp1)-(y-y_prediction)))/dim(X)[1]
  summary_result_2 <- rbind(temp_result,summary_result_2)  
  
#lasso_result <- 3
  ############################################################
  T1 <- as.vector(temp[,3])
  T2 <- as.vector(temp[,7])
  temp_result[1,1] <- length(which(T1[which(T2==0)] != 0)) #false positive for variable selection
  temp_result[1,2] <- length(which(T1[which(T2!=0)] == 0)) #false negative for variable selection
  temp_result[1,3] <- length(which(T1[which(T2!=0)] != 0))/length(which(T2 != 0)) #sensitivity for variable selection
  temp_result[1,4] <- length(which(T1[which(T2==0)] == 0))/length(which(T2 == 0)) #specificity for variable selection
  temp_result[1,5] <- mean((T1-T2)^2)  #MSE
  temp_result[1,6] <- sum((T1-T2)^2)  #SSE
  temp_result[1,7] <- mean(abs(T1-T2))  #MAE
  p_prediction <- round(X%*%T1,4)
  p_prediction[which(p_prediction<=0)] <- 0
  y_prediction <- rpois(dim(X)[1],p_prediction)
  temp_result[1,8] <- mean((y_prediction-mean(y))^2) #MSR  mean residual sum of squares
  temp_result[1,9] <- mean((y-y_prediction)^2) #MSE  mean estimation sum of squares
  temp_result[1,10] <- mean((y-mean(y))^2) #MST mean total sum of squares
  temp_result[1,11] <- 1-(sum((y_prediction-mean(y))^2)/(dim(X)[1]-length(which(T1!=0))))/(sum((y-mean(y))^2)/(dim(X)[1]-1)) #adjusted R2
  y_prediction[which(y_prediction==0)] <- 0.01
  temp_result[1,12] <- sum((y-y_prediction)^2/y_prediction)/dim(X)[1]
  temp1 <- y/y_prediction
  temp1[which(temp1==0)]<-0.0001
  temp_result[1,13] <- (2*sum(y*log(temp1)-(y-y_prediction)))/dim(X)[1]
  summary_result_3 <- rbind(temp_result,summary_result_3)  
  
#ridge_result <- 4
  ############################################################
  T1 <- as.vector(temp[,4])
  T2 <- as.vector(temp[,7])
  temp_result[1,1] <- length(which(T1[which(T2==0)] != 0)) #false positive for variable selection
  temp_result[1,2] <- length(which(T1[which(T2!=0)] == 0)) #false negative for variable selection
  temp_result[1,3] <- length(which(T1[which(T2!=0)] != 0))/length(which(T2 != 0)) #sensitivity for variable selection
  temp_result[1,4] <- length(which(T1[which(T2==0)] == 0))/length(which(T2 == 0)) #specificity for variable selection
  temp_result[1,5] <- mean((T1-T2)^2)  #MSE
  temp_result[1,6] <- sum((T1-T2)^2)  #SSE
  temp_result[1,7] <- mean(abs(T1-T2))  #MAE
  p_prediction <- round(X%*%T1,4)
  p_prediction[which(p_prediction<=0)] <- 0
  y_prediction <- rpois(dim(X)[1],p_prediction)
  temp_result[1,8] <- mean((y_prediction-mean(y))^2) #MSR  mean residual sum of squares
  temp_result[1,9] <- mean((y-y_prediction)^2) #MSE  mean estimation sum of squares
  temp_result[1,10] <- mean((y-mean(y))^2) #MST mean total sum of squares
  temp_result[1,11] <- 1-(sum((y_prediction-mean(y))^2)/(dim(X)[1]-length(which(T1!=0))))/(sum((y-mean(y))^2)/(dim(X)[1]-1)) #adjusted R2
  y_prediction[which(y_prediction==0)] <- 0.01
  temp_result[1,12] <- sum((y-y_prediction)^2/y_prediction)/dim(X)[1]
  temp1 <- y/y_prediction
  temp1[which(temp1==0)]<-0.0001
  temp_result[1,13] <- (2*sum(y*log(temp1)-(y-y_prediction)))/dim(X)[1]
  summary_result_4 <- rbind(temp_result,summary_result_4)
  
#EN_result <- 5
  ############################################################
  T1 <- as.vector(temp[,5])
  T2 <- as.vector(temp[,7])
  temp_result[1,1] <- length(which(T1[which(T2==0)] != 0)) #false positive for variable selection
  temp_result[1,2] <- length(which(T1[which(T2!=0)] == 0)) #false negative for variable selection
  temp_result[1,3] <- length(which(T1[which(T2!=0)] != 0))/length(which(T2 != 0)) #sensitivity for variable selection
  temp_result[1,4] <- length(which(T1[which(T2==0)] == 0))/length(which(T2 == 0)) #specificity for variable selection
  temp_result[1,5] <- mean((T1-T2)^2)  #MSE
  temp_result[1,6] <- sum((T1-T2)^2)  #SSE
  temp_result[1,7] <- mean(abs(T1-T2))  #MAE
  p_prediction <- round(X%*%T1,4)
  p_prediction[which(p_prediction<=0)] <- 0
  y_prediction <- rpois(dim(X)[1],p_prediction)
  temp_result[1,8] <- mean((y_prediction-mean(y))^2) #MSR  mean residual sum of squares
  temp_result[1,9] <- mean((y-y_prediction)^2) #MSE  mean estimation sum of squares
  temp_result[1,10] <- mean((y-mean(y))^2) #MST mean total sum of squares
  temp_result[1,11] <- 1-(sum((y_prediction-mean(y))^2)/(dim(X)[1]-length(which(T1!=0))))/(sum((y-mean(y))^2)/(dim(X)[1]-1)) #adjusted R2
  y_prediction[which(y_prediction==0)] <- 0.01
  temp_result[1,12] <- sum((y-y_prediction)^2/y_prediction)/dim(X)[1]
  temp1 <- y/y_prediction
  temp1[which(temp1==0)]<-0.0001
  temp_result[1,13] <- (2*sum(y*log(temp1)-(y-y_prediction)))/dim(X)[1]
  summary_result_5 <- rbind(temp_result,summary_result_5)
  
#glm_result <- 6
  ############################################################
  T1 <- as.vector(temp[,6])
  T2 <- as.vector(temp[,7])
  temp_result[1,1] <- length(which(T1[which(T2==0)] != 0)) #false positive for variable selection
  temp_result[1,2] <- length(which(T1[which(T2!=0)] == 0)) #false negative for variable selection
  temp_result[1,3] <- length(which(T1[which(T2!=0)] != 0))/length(which(T2 != 0)) #sensitivity for variable selection
  temp_result[1,4] <- length(which(T1[which(T2==0)] == 0))/length(which(T2 == 0)) #specificity for variable selection
  temp_result[1,5] <- mean((T1-T2)^2)  #MSE
  temp_result[1,6] <- sum((T1-T2)^2)  #SSE
  temp_result[1,7] <- mean(abs(T1-T2))  #MAE
  p_prediction <- round(X%*%T1,4)
  p_prediction[which(p_prediction<=0)] <- 0
  y_prediction <- rpois(dim(X)[1],p_prediction)
  temp_result[1,8] <- mean((y_prediction-mean(y))^2) #MSR  mean residual sum of squares
  temp_result[1,9] <- mean((y-y_prediction)^2) #MSE  mean estimation sum of squares
  temp_result[1,10] <- mean((y-mean(y))^2) #MST mean total sum of squares
  temp_result[1,11] <- 1-(sum((y_prediction-mean(y))^2)/(dim(X)[1]-length(which(T1!=0))))/(sum((y-mean(y))^2)/(dim(X)[1]-1)) #adjusted R2
  y_prediction[which(y_prediction==0)] <- 0.01
  temp_result[1,12] <- sum((y-y_prediction)^2/y_prediction)/dim(X)[1]
  temp1 <- y/y_prediction
  temp1[which(temp1==0)]<-0.0001
  temp_result[1,13] <- (2*sum(y*log(temp1)-(y-y_prediction)))/dim(X)[1]
  summary_result_6 <- rbind(temp_result,summary_result_6) 

}
  T = T+1
  if (T ==40){
    break
  }
}

write.csv(summary_result_1,file=paste('summary_result',1,'.csv',seq=""))
write.csv(summary_result_2,file=paste('summary_result',2,'.csv',seq=""))
write.csv(summary_result_3,file=paste('summary_result',3,'.csv',seq=""))
write.csv(summary_result_4,file=paste('summary_result',4,'.csv',seq=""))
write.csv(summary_result_5,file=paste('summary_result',5,'.csv',seq=""))
write.csv(summary_result_6,file=paste('summary_result',6,'.csv',seq=""))

